package ar.org.centro8.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Persona implements Comparable<Persona>{
    
    private String nombre;
    private String apellido;
    private int edad;

    @Override
    public int compareTo(Persona para) {
        String thisPersona=this.getNombre();
        String paraPersona=para.getNombre();
        return thisPersona.compareTo(paraPersona);
    }

}

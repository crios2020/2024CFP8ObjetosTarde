package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@EqualsAndHashCode
//@Data       //getter setter toString equalsAndHashCode
@AllArgsConstructor
public class Auto implements Comparable<Auto> {
    private String marca;
    private String modelo;
    private String color;
    @Override
    public int compareTo(Auto para) {
        String thisAuto = this.getMarca()+","+this.getModelo()+","+this.getColor();
        String paraAuto = para.getMarca()+","+para.getModelo()+","+para.getColor();
        return thisAuto.compareTo(paraAuto);
    }

    //@Override
    //public int hashCode() {
    //    return toString().hashCode();
    //}
    //@Override
    //public boolean equals(Object obj) {
    //    if (obj == null) return false;
    //    return this.hashCode()==obj.hashCode();
    //}
    

    
}

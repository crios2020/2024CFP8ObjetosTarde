
//declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores

    /**
     * Método deprecado, por Carlos Rios el 15/03/2024, por 
     * resultar inseguro. Usar en su reemplazo
     * Auto(String marca, String modelo, String color)
     */
    @Deprecated
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //métodos
    void acelerar(){
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);       
        //llamado de método de la misma clase
    }

    //método sobrecargado
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }


    void frenar(){
        velocidad-=10;
    }

    //void no devuelve valor
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //con valor de retorno
    int obtenerVelocidad(){
        return velocidad;
    }

    String getEstado(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }

    @Override
    public String toString(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }

}//end class

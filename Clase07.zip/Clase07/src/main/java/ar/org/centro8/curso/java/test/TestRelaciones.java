package ar.org.centro8.curso.java.test;

import java.util.ArrayList;

import ar.org.centro8.curso.java.entities.ClienteEmpresa;
import ar.org.centro8.curso.java.entities.ClientePersona;
import ar.org.centro8.curso.java.entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        //Test de objetos MOCKS (objetos simulados)

        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(250000);
        cuenta1.depositar(120000);
        cuenta1.debitar(50000);
        System.out.println(cuenta1);
        cuenta1.debitar(600000);
        System.out.println(cuenta1);
        
        System.out.println("-- clienteConyuge1 --");
        ClientePersona clienteConyuge1=new ClientePersona(
                        1, 
                        "Ana Perez", 
                        32, 
                        new Cuenta(2, "arg$")
                    );
        clienteConyuge1.getCuenta().depositar(560000);
        clienteConyuge1.getCuenta().depositar(850000);
        clienteConyuge1.getCuenta().debitar(36000);
        System.out.println(clienteConyuge1);

        System.out.println("-- clienteConyuge2 --");
        ClientePersona clienteConyuge2=new ClientePersona(
                    2,
                    "Raul Ortiz",
                    32,
                    clienteConyuge1.getCuenta()
        );
        clienteConyuge2.getCuenta().debitar(1200000);
        System.out.println(clienteConyuge2);
        System.out.println(clienteConyuge1);

        //lawlercarlospatricio
        //https://www.youtube.com/watch?v=0PAKKNOpZPA&list=PLMLmotKSEKYfobV2_eyZxVxc88E-27k7t&index=54
        //https://www.youtube.com/watch?v=T54v6wfX1Yo&list=PLMLmotKSEKYfobV2_eyZxVxc88E-27k7t&index=55

        //Video de Springboot
        //https://www.youtube.com/watch?v=8X2acANBuLk

        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(
                        3, 
                        "Gabriel Soto", 
                        0,
                        4,
                        "arg$");
        clientePersona1.getCuenta().depositar(400000);
        System.out.println(clientePersona1);


        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(
                            1, 
                            "TodoLimpio SRL", 
                            "Medrano 164"
        );
        ArrayList<Cuenta>cuentas=clienteEmpresa1.getCuentas();
        cuentas.add(new Cuenta(10, "arg$"));                // 0
        cuentas.add(new Cuenta(11, "reales"));              // 1
        cuentas.add(new Cuenta(12,"U$S"));                  // 2
        cuentas.get(0).depositar(6000000);  
        cuentas.get(0).depositar(7500000);
        cuentas.get(0).debitar(1200000);
        cuentas.get(1).depositar(140000);
        cuentas.get(2).depositar(12000);
        System.out.println(clienteEmpresa1);

        
        

    }
}

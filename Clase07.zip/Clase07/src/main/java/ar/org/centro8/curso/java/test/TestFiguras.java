package ar.org.centro8.curso.java.test;

import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import ar.org.centro8.curso.java.entities.Circulo;
import ar.org.centro8.curso.java.entities.Rectangulo;
import ar.org.centro8.curso.java.entities.Triangulo;

public class TestFiguras {
    public static void main(String[] args) {

        DecimalFormat df=new DecimalFormat("0.00");

        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo(100,120);
        System.out.println("Perimetro: "+df.format(rectangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(rectangulo1.getSuperficie()));
        //JOptionPane.showMessageDialog(
        //    null, "Perimetro: "+rectangulo1.getPerimetro());
        
        System.out.println("-- triangulo1 --");
        Triangulo triangulo1=new Triangulo(100, 120);
        System.out.println("Perimetro: "+df.format(triangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(triangulo1.getSuperficie()));

        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo(100);
        System.out.println("Perimetro: "+df.format(circulo1.getPerimetro()));
        System.out.println("Supergicie: "+df.format(circulo1.getSuperficie()));
        
    
    }
}

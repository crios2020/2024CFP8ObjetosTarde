package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Circulo {
    
    private double radio;

    public double getPerimetro(){
        return Math.PI*2*radio;
    }

    public double getSuperficie(){
        return Math.PI*Math.pow(radio, 2);
    }

}

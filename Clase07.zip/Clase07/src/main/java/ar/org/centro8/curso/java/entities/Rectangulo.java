package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Rectangulo {
    private double lado1;
    private double lado2;

    public double getPerimetro(){
        return (lado1+lado2)*2;
    }

    public double getSuperficie(){
        return lado1*lado2;
    }

}

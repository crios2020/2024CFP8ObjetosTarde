package ar.org.centro8.curso.java.clase04;

public class Clase04 {
    public static void main(String[] args) {
        System.out.println("Clase04");

        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(
                    1, 
                    "Ana", 
                    "Mendez", 
                    867000);
        //empleado1.sueldoBasico=333333999;
        empleado1.setSueldoBasico(99555555);
        System.out.println(empleado1);

        System.out.println("-- auto1 --");
        Auto auto1=new Auto(
                                "Fiat", 
                                "500", 
                                "Rojo", 
                                0);
        //auto1.velocidad=800;
        auto1.acelerar(34);
        auto1.setColor("Verde");
        System.out.println(auto1);
        

        
    }
}

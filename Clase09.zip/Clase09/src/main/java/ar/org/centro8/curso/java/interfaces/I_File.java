package ar.org.centro8.curso.java.interfaces;

public interface I_File {

    /*
     * Que una interface en Java?
     * - Las interfaces no tienen constructores o atributos de objetos.
     * - Todos los miembros de una interface son public.
     * - Los métodos de una interface son abstractos.
     * - Puede contenter atributos final o static.
     * 
     * - Una clase puede implementar todas las interfaces que necesite.
     * 
     */


    /**
     * Método para escribir el archivo
     * @param text texto a escribir
     */
    void setText(String text);

    /**
     * Método para leer el archivo
     * @return retorna el texto del archivo
     */
    String getText();

    //Método default JDK 8 o sup.
    public default void info(){
        System.out.println("Interface I_File");
    }

}

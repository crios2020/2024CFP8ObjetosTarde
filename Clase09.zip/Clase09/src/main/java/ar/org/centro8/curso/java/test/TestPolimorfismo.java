package ar.org.centro8.curso.java.test;

import java.text.DecimalFormat;

import ar.org.centro8.curso.java.entities.Circulo;
import ar.org.centro8.curso.java.entities.Figura;
import ar.org.centro8.curso.java.entities.Rectangulo;
import ar.org.centro8.curso.java.entities.Triangulo;

public class TestPolimorfismo {
    public static void main(String[] args) {
        //Polimorfismo - Poliformismo

        Figura figura=null;

        //figura=new Rectangulo(100,120);
        //figura=new Triangulo(100,120);
        //figura=new Circulo(100);

        //app
        DecimalFormat df=new DecimalFormat("0.00");
        System.out.println(figura.getEstado());
        System.out.println("Perimetro: "
                    +df.format(figura.getPerimetro()));
        System.out.println("Superficie: "
                    +df.format(figura.getSuperficie()));
        //System.out.println(((Rectangulo)figura).getBase());




    }
}

package ar.org.centro8.curso.java.test;

import java.util.Scanner;

import ar.org.centro8.curso.java.interfaces.I_File;
import ar.org.centro8.curso.java.utils.FileBinary;
import ar.org.centro8.curso.java.utils.FileText;

public class TestInterfaces {
    public static void main(String[] args) throws Exception {
        I_File file=null;

        //file=new FileText();
        //file=new FileBinary();

        System.out.println("Ingrese 'FileText' o 'FileBinary': ");
        String in=new Scanner(System.in).nextLine();

        //if(in.equalsIgnoreCase("FileText")) 
        //    file=new FileText();
        //if(in.equalsIgnoreCase("FileBinary"))
        //    file=new FileBinary();

        file=(I_File)Class
                        .forName("ar.org.centro8.curso.java.utils."+in)
                        //.newInstance();       //Deprecado
                        .getConstructor(null)
                        .newInstance(null);
        
        //app
        file.setText("Hola a todos!");
        System.out.println(file.getText());
        file.info();

       //reflectividad
 /*
         * Que es una clase: una clase se encuentra como sustantivos en la vida real, 
         *      se escribe en singular iniciando en mayúscula. Ej Auto, Alumno, Profesor, Vendedor, Articulo
         * Clases en Java: son instancias de la clase java.lang.Class
         * 
         * 
         * Que son los atributos: los atributos son variables contenidas dentro de la clase y 
         *      describen a la clase, tienen un tipo de datos.
         * Atributos en Java: son instancias de la clase java.lang.reflect.Field
         * 
         * Que son los métodos: los métodos son acciones que realiza una clase y se expresan como verbos
         * Métodos en Java: son instancias de la clase java.lang.reflect.Method
         * 
         * Que son los objetos: son instancias de la clase que representan una situación en particular
         *      y tienen estado propio.
         * 
         * Desacoplamiento(deseado) y cohesión de clases(deseado) 
         * Acoplamniento(no deseado)
         * 
         * Constructores: son métodos que se usan para inicializar un objeto, pueden existir varios
         *      constructores sobrecargados, Tienen el nombre nombre que la clase, no tiene devolución de valor.
         *      Si la clase no tiene constructor, java agrega un constructor vacio en tiempo de compilación
         * constructores en java: son instancias de la clase java.lang.reflect.Constructor
         * 
         */



    }
}

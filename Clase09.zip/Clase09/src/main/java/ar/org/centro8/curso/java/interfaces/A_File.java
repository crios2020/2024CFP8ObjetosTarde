package ar.org.centro8.curso.java.interfaces;

import java.io.File;

public abstract class A_File {

    private File file;

    public A_File(File file) {
        this.file = file;
    }

    /**
     * Método para escribir el archivo
     * @param text texto a escribir
     */
    public abstract void setText(String text);

    /**
     * Método para leer el archivo
     * @return retorna el texto del archivo
     */
    public abstract String getText(); 
}

package ar.org.centro8.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestException {
    public static void main(String[] args) {
        //System.out.println(10/0);
        //System.out.println("Esta linea no se ejecuta!");

        /*
         * //Estructura try catch
         * 
         * try{                                     //obligatorio
         *      //colocar aquí todas las sentencias que pueden
         *      //lanzar exception(error)
         *      //si se ejecuta sin error, termina el bloque try y continua
         *      //el control del programa en finally o después de la estructura.
         *      //si ocurre una exception, termina el control de este bloque
         *      // y continua en el bloque catch.
         *      // Las sentencias dentro de este bloque tienen más costo
         *      // de hardware.
         * } catch(Exception e){                    //obligatorio
         *      //Este bloque se ejecuta en caso de excpetion en try
         *      //Se recibe como parámetro un objeto de Exception. 
         *      //se contiene el error!
         *      //El bloque termina normalmente y continua el control en finally
         * } finally {                              //opcional
         *      //Este bloque se ejecuta siémpre ocurra exception o no
         *      //Las variables declaracas en otros bloques están fuera
         *      // de scoped(alcance)
         * }
         * 
         */
        /*
        try {
            System.out.println(10/0);
            System.out.println("Esta sentencia no se ejecuta!");
        } catch (Exception e) {
            System.out.println("Ocurrio un error!!");
            System.out.println(e);
        } finally {
            System.out.println("Este bloque se ejecuta siempre!");
        }
        System.out.println("El programa termina normalmente!");
        */

        //GeneradorException.generar(true);
        

        try {
            //GeneradorException.generar();    
            //GeneradorException.generar(true);
            //GeneradorException.generar("26x");
            //GeneradorException.generar(null,30);
            //GeneradorException.generar("hola",30);
            FileReader in=new FileReader("texto.txt");
        //}catch(ArrayIndexOutOfBoundsException e){ 
            System.out.println("Indice fuera de rango!");
        }catch(ArithmeticException e){ 
            System.out.println("Error división /0");
        }catch(NumberFormatException e){ 
            System.out.println("Formato incorrecto!");
        }catch(NullPointerException e){ 
            System.out.println("Puntero Nulo!");
        //}catch(StringIndexOutOfBoundsException e){ 
        //  System.out.println("Indice fuera de rango!");
        //}catch(ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { 
        //  System.out.println("Indice fuera de rango!");
        }catch(FileNotFoundException e){ 
            System.out.println("Archivo no encontrado!");
        }catch(IOException e){ 
            System.out.println("Problemas de IO");
        }catch(IndexOutOfBoundsException e){ 
            System.out.println("Indice fuera de rango!"); 
        }catch(Exception e) {
            System.out.println("Ocurrio un error no esperado!");
        }

    }
}

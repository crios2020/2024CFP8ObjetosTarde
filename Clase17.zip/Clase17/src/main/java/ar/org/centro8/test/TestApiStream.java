package ar.org.centro8.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.entities.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        
        List<Persona> personas=new ArrayList();
        personas.add(new Persona("Laura", "Perez", 35));
        personas.add(new Persona("Juan", "Perez", 32));
        personas.add(new Persona("Micaela", "Moreno", 27));
        personas.add(new Persona("Rosa", "Monte", 42));
        personas.add(new Persona("Victor", "Sosa", 50));
        personas.add(new Persona("Laura", "Segovia", 50));
        personas.add(new Persona("Lautaro", "Martinez", 25));
        personas.add(new Persona("Lara", "Gonsalez", 50));


        //select * from personas
        //personas.forEach(System.out::println);
        personas.stream().forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas where nombre='Laura';
        
        //for(Persona persona: personas){
        //    if(persona.getNombre().equalsIgnoreCase("laura")){
        //        System.out.println(persona);
        //    }
        //}
        
        personas
                    .stream()
                    .filter(persona->persona
                                            .getNombre()
                                            .equalsIgnoreCase("laura"))
                    .forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas where nombre like 'La%';
        personas
                    .stream()
                    .filter(persona->persona
                                            .getNombre()
                                            .toLowerCase()
                                            .startsWith("la")) 
                    .forEach(System.out::println);
                    //.forEach(persona->System.out.println(persona));

        System.out.println("**********************************************");
        //select * from personas where nombre like '%a';
        personas
                    .stream()
                    .filter(persona->persona
                                            .getNombre()
                                            .toLowerCase()
                                            .endsWith("a"))
                    .forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas where nombre like '%ar%';
        personas
                    .stream()
                    .filter(persona->persona
                                            .getNombre()
                                            .toLowerCase()
                                            .contains("ar"))
                    .forEach(System.out::println);

        //System.out.println("**********************************************");
        //select * from personas where nombre='laura' or nombre='victor';
        personas
                .stream()
                .filter(persona->
                                    persona
                                            .getNombre()
                                            .toLowerCase()
                                            .equalsIgnoreCase("laura")
                                ||
                                    persona
                                            .getNombre()
                                            .toLowerCase()
                                            .equalsIgnoreCase("victor"))
                .forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas where nombre='laura' and edad>=40;
        personas
                .stream()
                .filter(persona->
                                    persona
                                            .getNombre()
                                            .toLowerCase()
                                            .equalsIgnoreCase("laura")
                                &&
                                    persona
                                            .getEdad()>=40)
                .forEach(System.out::println);
        
        System.out.println("**********************************************");
        //select * from personas where edad between 30 and 50;
        personas
                .stream()
                .filter(persona->
                            persona
                                    .getEdad()>=30
                            &&
                            persona
                                    .getEdad()<=50)
                .forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas order by nombre;
        // personas
        //         .stream()
        //         .sorted(Comparator.comparing(Persona::getNombre))
        //         .forEach(System.out::println);

        personas
                .stream()
                .sorted()
                .forEach(System.out::println);


        System.out.println("**********************************************");
        //select * from personas order by nombre desc;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre).reversed())
                .forEach(System.out::println);

        System.out.println("**********************************************");
        //select * from personas order by apellido, nombre;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido)
                        .thenComparing(Persona::getNombre))
                .forEach(System.out::println);
        

        System.out.println("**********************************************");
        //select max(edad) from personas;
        int edadMaxima=personas
                                .stream()
                                .max(Comparator.comparingInt(Persona::getEdad))
                                .get()
                                .getEdad();
        System.out.println("Edad Máxima: "+edadMaxima);


        System.out.println("**********************************************");
        //select * from personas where edad=(select max(edad) from personas );
        personas
                .stream()
                .filter(persona->persona.getEdad()==edadMaxima)
                .forEach(System.out::println);


        
        
    }
}

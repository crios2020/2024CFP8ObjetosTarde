package ar.org.centro8.curso.java.clase04;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//@ToString
//@Getter
//@Setter
@Data
@AllArgsConstructor
public class Auto {

    private String marca;
    private String modelo;
    private String color;
    private int velocidad;

    public void acelerar(){                     //acelerar
        acelerar(10);
    }

    public void acelerar(int kilometros){       //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    public void frenar(int kilometros){
        velocidad-=kilometros;
    }
}

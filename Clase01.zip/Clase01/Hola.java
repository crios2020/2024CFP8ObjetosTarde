/**
 * Clase principal del proyecto
 */
public class Hola{
    /**
     * Punto de entrada del proyecto
     * @param args  argumentos que ingresan desde consola
     */
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!");
        System.out.println("Versión de Java: "+
                System.getProperty("java.version"));

        //Extensiones
        //Extension Pack for Java Microsoft
        //Todo Tree Gruntfuggly

        //Comentarios de una sola linéa
        /*
            Bloque 
            de
            Comentarios 
         */
        /**
            Comentario Java Doc
            Este comentario esta disponible por fuera del archivo
            binario.
            Este comentario debe colocarse delante de la 
            declaración de método o clase. 
         */
        //TODO Tarea pendiente

        /*
            Lenguajes de tipado fuerte: Java C# C++ VisualBasic
            Lenguajes de tipado debil:  Python, JavaScript, php


            Almacenamiento RAM:         Volatil         Caro        Veloz
            Almacenamiento DiscoDuro:   Persistente     Economico   Lento
        */

        //Tipo de datos primitivos

        //Tipo de datos enteros

        //Tipo de datos boolean         1 byte
        boolean bo=true;
        System.out.println(bo);

        /*
         * 1
         * --------
         */

         



    }
}
package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.CursoRepository;

public class TestCursoRepository {
    public static void main(String[] args) {
        CursoRepository cursoRepository=new CursoRepository();

        System.out.println("-- Método .save() --");
        Curso curso=new Curso(
                                    0, 
                                    "Java", 
                                    "Rios", 
                                    Dia.LUNES, 
                                    Turno.NOCHE);
    
        cursoRepository.save(curso);
        System.out.println(curso);

        System.out.println("-- Método .getById()");
        System.out.println(cursoRepository.getById(10));

        System.out.println("-- Método remove() --");
        cursoRepository.remove(cursoRepository.getById(26));

        System.out.println("-- M{etodo getLikeTitulo()");
        cursoRepository.getLikeTitulo("ja").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        cursoRepository.getAll().forEach(System.out::println);

    }
}

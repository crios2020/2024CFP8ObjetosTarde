-- Active: 1701117325170@@127.0.0.1@3306@colegio
use colegio;

INSERT INTO cursos (titulo, profesor, dia, turno) VALUES
    ('Matemáticas', 'Juan Pérez', 'LUNES', 'MAÑANA'),
    ('Historia', 'María Gómez', 'MARTES', 'TARDE'),
    ('Física', 'Carlos Rodríguez', 'MIERCOLES', 'NOCHE'),
    ('Literatura', 'Ana López', 'JUEVES', 'MAÑANA'),
    ('Química', 'Pedro Sánchez', 'VIERNES', 'TARDE'),
    ('Inglés', 'Laura Torres', 'LUNES', 'NOCHE'),
    ('Biología', 'Fernando Ramírez', 'MARTES', 'MAÑANA'),
    ('Geografía', 'Sara Martínez', 'MIERCOLES', 'TARDE'),
    ('Programación', 'Luisa González', 'JUEVES', 'NOCHE'),
    ('Arte', 'Diego Herrera', 'VIERNES', 'MAÑANA'),
    ('Economía', 'Carolina Castro', 'LUNES', 'TARDE'),
    ('Música', 'Manuel Vargas', 'MARTES', 'NOCHE'),
    ('Filosofía', 'Gabriela Ríos', 'MIERCOLES', 'MAÑANA'),
    ('Deportes', 'Roberto Silva', 'JUEVES', 'TARDE'),
    ('Psicología', 'Patricia Mendoza', 'VIERNES', 'NOCHE'),
    ('Sociología', 'Ricardo Blanco', 'LUNES', 'MAÑANA'),
    ('Cálculo', 'Carmen Morales', 'MARTES', 'TARDE'),
    ('Dibujo', 'Pedro Gutiérrez', 'MIERCOLES', 'NOCHE'),
    ('Estadística', 'Laura Rojas', 'JUEVES', 'MAÑANA'),
    ('Ciencias', 'Miguel Torres', 'VIERNES', 'TARDE');

INSERT INTO alumnos (nombre, apellido, edad, idCurso) VALUES
    ('Juan', 'Gómez', 20, 1),
    ('María', 'López', 22, 1),
    ('Pedro', 'Rodríguez', 19, 1),
    ('Ana', 'Sánchez', 21, 1),
    ('Luis', 'Martínez', 25, 1),
    ('Laura', 'Torres', 23, 1),
    ('Carlos', 'Ramírez', 24, 1),
    ('Sara', 'González', 20, 1),
    ('Miguel', 'Herrera', 22, 1),
    ('Fernanda', 'Castro', 19, 1),
    ('Diego', 'Vargas', 21, 1),
    ('Gabriela', 'Ríos', 25, 1),
    ('Roberto', 'Silva', 23, 1),
    ('Patricia', 'Mendoza', 24, 1),
    ('Ricardo', 'Blanco', 20, 1),
    ('Carmen', 'Morales', 22, 1),
    ('Pedro', 'Gutiérrez', 19, 1),
    ('Laura', 'Rojas', 21, 1),
    ('Miguel', 'Torres', 25, 1),
    ('Carolina', 'Hernández', 23, 1);


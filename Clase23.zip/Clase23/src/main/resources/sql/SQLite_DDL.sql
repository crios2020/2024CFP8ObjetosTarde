DROP TABLE IF EXISTS alumnos;
DROP TABLE IF EXISTS cursos;

create table cursos(
    id integer,
    titulo text not null check(length(titulo)>=3 AND LENGTH(titulo)<=25),
    profesor text not null check(length(profesor)>=3 AND LENGTH(profesor)<=25),
    dia NOT NULL CHECK (dia in('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES')),
    turno NOT NULL CHECK(turno in('MAÑANA','TARDE','NOCHE')),
    activo boolean default TRUE,
    PRIMARY KEY(id)
);

create table alumnos (
    id integer,
    nombre text not null check(length(nombre)>=3 AND LENGTH(nombre)<=25),
    apellido text not null check(length(apellido)>=3 AND LENGTH(apellido)<=25),
    edad integer not null check(edad>=18 and edad<=120),
    idCurso int not NULL REFERENCES cursos(id),
    activo boolean default TRUE,
    PRIMARY key(id)
);







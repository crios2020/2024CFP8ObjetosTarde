public class Clase02{
    public static void main(String[] args) {
        // clase 02

        //Tipo de datos primitivos

        //Tipo de datos enteros

        //Tipo de datos boolean         1 byte
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);

        //Tipo de datos byte            1 byte      -128 a 127
        byte by=100;
        System.out.println(by);

        //Tipo de datos short           2 bytes -32768 a 32767
        short sh=32000;
        System.out.println(sh);

        //Tipo de datos int             4 bytes 
        int in=2000000000;
        System.out.println(in);

        //Tipo de datos long            8 bytes
        long lo=20000000000L;
        System.out.println(lo);

        //Tipo de char                  2 bytes unsigned
        char ch=65;
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);
        System.out.println((int)ch);
        ch='x';
        System.out.println(ch);

        //Tipo de datos de punto flotante
        
        //Tipo de datos float   32 bits
        float fl=2.56f;
        System.out.println(fl);;

        //Tipo de datos double  64 bits
        double dl=2.56;
        System.out.println(dl);

        fl=10;
        dl=10;
        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=100;
        dl=100;
        System.out.println(fl/3);
        System.out.println(dl/3);

        //Clase String
        String st="HOLA";
        System.out.println(st);

        //Tipo de datos var
        var var1=true;          //boolean
        var1=false;
        //var1=3;
        var var2=20;            //int
        var var3=20L;           //long
        var var4='f';           //char
        var var5=3.45;          //double
        var var6=3.45f;         //float
        var var7=3.45d;         //double
        var var8="h";           //String        

        funcion(var1);
        funcion(var2);
        funcion(var3);
        funcion(var4);
        funcion(var5);
        funcion(var6);
        funcion(var7);
        funcion(var8);

        String texto="Esto es una cadena de texto!";
        System.out.println(texto);

        //Recorrido del vector texto
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print(car);
        }
        System.out.println();

        //Imprimir el texto todo en mayusculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            if(car>=97 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();

        //Operador ternario ?
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print((car>=97 && car<=122)?car-=32:car);
        }
        System.out.println();

        //Imprimir todo en minusculas
        for(int a=0; a<texto.length(); a++){
            char car=texto.charAt(a);
            System.out.print((car>=65 && car<=90)?car+=32:car);
        }
        System.out.println();

        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());
        
        /*
         * Paradigma de la Programación Orientada a Objetos
         * 
         * Clase: una clase representa cosas sustantivas y concretas
         *          de la realidad de un negocio. Las clases se 
         *          identifican en singular y la primer letra en 
         *          mayúsculas.
         * 
         * 
         * Atributos: son adjetivos que describen a la clase.
         *            son variables contenidas dentro de una clase
         *            y pertenecen a un tipo primitivo.
         * 
         * Métodos:   son acciones que realiza la clase, y se detectan
         *            como verbos.
         * 
         * 
         * 
         * 
         */


    }

    public static void funcion(String x){
        System.out.println("Se recibio un valor String");
    }
    public static void funcion(int x){
        System.out.println("Se recibio un valor int");
    }
    public static void funcion(long x){
        System.out.println("Se recibio un valor long");
    }
    public static void funcion(float x){
        System.out.println("Se recibio un valor float");
    }
    public static void funcion(double x){
        System.out.println("Se recibio un valor double");
    }
    public static void funcion(char x){
        System.out.println("Se recibio un valor char");
    }
    public static void funcion(boolean x){
        System.out.println("Se recibio un valor boolean");
    }
}
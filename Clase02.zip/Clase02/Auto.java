public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //métodos


}//end class Auto

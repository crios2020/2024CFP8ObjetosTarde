package ar.org.centro8.test;

import java.net.InetAddress;
import java.util.Calendar;

public class TestPropiedades {
    public static void main(String[] args) {
        //System.out.println(System.getProperties());
        System.getProperties().forEach((k,v)->System.out.println(k+": "+v));

        System.out.println("**************************************************");

        //System.out.println(System.getenv());
        System.getenv().forEach((k,v)->System.out.println(k+": "+v));

        System.out.println("**************************************************");
        System.out.println("Sistema Operativo");
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));

        System.out.println("Version de Java");
        System.out.println(System.getProperty("java.vm.name"));
        System.out.println(System.getProperty("java.vm.version"));

        System.out.println("Nombre de Usuario");
        System.out.println(System.getProperty("user.name"));

        System.out.println("Ubicación");
        System.out.println(Calendar
                                    .getInstance()
                                    .getTimeZone()
                                    .getID()
                                    .replace("/", " ")
                                    .replace("_", " "));

        System.out.println("ip");
        try{
            System.out.println(InetAddress.getLocalHost().getHostAddress());
        }catch(Exception e){
            System.out.println(e);
        }

    }
}

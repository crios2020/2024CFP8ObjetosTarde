package ar.org.centro8.curso.java.entities;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ClientePersona {

    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;

    

}

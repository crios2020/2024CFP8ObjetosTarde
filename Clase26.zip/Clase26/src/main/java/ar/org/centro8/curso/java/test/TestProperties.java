package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.utils.Properties;

public class TestProperties {
    public static void main(String[] args) {
        System.out.println(Properties.getSO());
        System.out.println(Properties.getJava());
        System.out.println(Properties.getUser());
        System.out.println(Properties.getLocation());
        System.out.println(Properties.getIp());
        System.out.println(Properties.getDate());
    }
}

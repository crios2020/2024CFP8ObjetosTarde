package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.AlumnoRepository;

public class TestAlumnoRepository {
    public static void main(String[] args) {
        AlumnoRepository alumnoRepository=new AlumnoRepository();
        
        System.out.println("-- Método .save() --");
        Alumno alumno=new Alumno(
                                    0,
                                    "Raul",
                                    "Vargas",
                                    25,
                                    1);
        alumnoRepository.save(alumno);
        System.out.println(alumno);

        System.out.println("-- Método .getById() --");
        System.out.println(alumnoRepository.getById(21));

        System.out.println("-- Método .remove() --");
        alumnoRepository.remove(alumnoRepository.getById(22));

        System.out.println("-- Método .getLikeApellido() --");
        alumnoRepository.getLikeApellido("ez").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        alumnoRepository.getAll().forEach(System.out::println);


    }
}


-- 1. Obtener todos los cursos activos:
SELECT * FROM cursos WHERE activo = true;

-- 2. Obtener el título y profesor de los cursos que se imparten los martes en la mañana:
SELECT titulo, profesor FROM cursos WHERE dia = 'MARTES' AND turno = 'MAÑANA';

-- 3. Obtener el nombre y apellido de los alumnos mayores de 20 años:
SELECT nombre, apellido FROM alumnos WHERE edad > 20;

-- 4. Obtener el título del curso y nombre del profesor de los cursos en los que hay alumnos inscritos:
SELECT c.titulo, c.profesor FROM cursos c INNER JOIN alumnos a ON c.id = a.idCurso;

-- 5. Obtener la cantidad de alumnos por curso:
SELECT c.titulo, COUNT(a.id) AS cantidad_alumnos FROM cursos c LEFT JOIN alumnos a ON c.id = a.idCurso GROUP BY c.id;

-- 6. Obtener los cursos que no tienen ningún alumno inscrito:
SELECT c.titulo FROM cursos c LEFT JOIN alumnos a ON c.id = a.idCurso WHERE a.idCurso IS NULL;

-- 7. Actualizar el turno del curso con ID 3 a "TARDE":
UPDATE cursos SET turno = 'TARDE' WHERE id = 3;

-- 8. Eliminar el alumno con ID 5:
DELETE FROM alumnos WHERE id = 5;

-- 9. Obtener el nombre del curso y nombre del profesor de los cursos activos ordenados alfabéticamente por el nombre del curso:
SELECT titulo, profesor FROM cursos WHERE activo = true ORDER BY titulo ASC;

-- 10. Obtener el nombre del alumno y título del curso de los alumnos inscritos en cursos activos impartidos los jueves:
SELECT a.nombre, c.titulo FROM alumnos a INNER JOIN cursos c ON a.idCurso = c.id WHERE a.activo = true AND c.dia = 'JUEVES';



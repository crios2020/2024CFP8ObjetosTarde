package ar.org.centro8.curso.java.test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.curso.java.entities.Auto;

public class TestCollection {
    public static void main(String[] args) {
        
        //Vectores - Arreglos
        Auto[] autos=new Auto[4];

        autos[0]=new Auto("Ford", "Ka", "Negro");
        autos[1]=new Auto("Fiat", "Toro", "Rojo");
        autos[2]=new Auto("Citroen", "C3", "Verde");
        autos[3]=new Auto("Renault", "Kangoo", "Bordo");

        //Recorrido con indices
        //for(int a=0; a<autos.length; a++){
        //    System.out.println(autos[a]);
        //}

        //Recorrido forEach
        for(Auto auto : autos) System.out.println(auto);

        //Interface List
        List lista1=new ArrayList();
        //List lista1=new LinkedList();
        //List lista1=new Vector();

        lista1.add(new Auto("Peugeot","205","Gris"));   //0
        lista1.add(new Auto("VW", "Gol", "Blanco"));    //1
        lista1.add("Hola");                                              //2
        lista1.add("Mundo");                                             //3
        lista1.add(26);                                                  //4

        lista1.add(1,"Java");
        lista1.remove(4);

        System.out.println("****************************************");
        //Recorrido con indices
        //for(int a=0; a<lista1.size(); a++){
        //    lista1.get(a);
        //}
        
        //Recorrido forEach
        //for(Object o: lista1) System.out.println(o);
        
        //Método default forEach()
        //lista1.forEach(o->System.out.println(o));

        //lista1.forEach(o->{
        //    System.out.println(o);
        //    System.out.println("-");
        //});

        lista1.forEach(System.out::println);

        //Uso de Generics <>        JDK 5 o sup
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Honda", "Civic", "Blanco"));

        //copiar autos del vector autos a lista2
        for(Auto auto: autos) lista2.add(auto);

        //copiar autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });

        //Recorrido de lista2
        System.out.println("****************************************");
        lista2.forEach(System.out::println);

        //Interface SET
        Set<String> semana=null;

        //Implementación HashSet: es la más veloz, pero no garantiza 
        // el orden de los elementos
        //semana=new HashSet();

        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        // por orden de ingreso
        semana=new LinkedHashSet();

        //Implementación TreeSet:   Almacena elementos en un arbol balaceado
        // por orden natural
        semana=new TreeSet();

        //app
        semana.add("Lunes");
        semana.add("Martes");
        semana.add("Miércoles");
        semana.add("Jueves");
        semana.add("Viernes");
        semana.add("Sábado");
        semana.add("Domingo");
        semana.add("Lunes");
        semana.add("Lunes");
        semana.add("Martes");
        semana.forEach(System.out::println);

        //Set Autos
        Set<Auto>setAutos=null;
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();

        setAutos.add(new Auto("Siam", "Ditella", "negro"));
        setAutos.add(new Auto("Honda", "Civic", "Blanco"));
        setAutos.addAll(lista2);
        //setAutos.forEach(System.out::println);
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));

        /*
         *  Pila        LIFO
         *      Last In First Out
         * 
         *  Cola        FIFO
         *      First In First Out
         * 
         */

        //Clase Stack           Pilas
        Stack<Auto> pilaAutos=new Stack();
        
        //método .push(); apila elementos
        pilaAutos.push(new Auto(
                            "Dodge",
                            "1500", 
                            "Naranja"));
        pilaAutos.addAll(lista2);

        System.out.println("*********************************");
        pilaAutos.forEach(System.out::println);

        System.out.println("Longitud de pila: "+pilaAutos.size());
        while(!pilaAutos.empty()){
            //método .pop() desapila un elemento
            System.out.println(pilaAutos.pop());
        }
        System.out.println("Longitud de pila: "+pilaAutos.size());

        //Clase ArrayDeque      Colas
        ArrayDeque<Auto>colaAutos=new ArrayDeque();

        //método .offer() //encola un elemento
        colaAutos.offer(new Auto(
            "Dodge", 
            "Caravan", 
            "Negra"));
        
        colaAutos.addAll(lista2);
        System.out.println("*********************************");
        colaAutos.forEach(System.out::println);

        System.out.println("Longitud de cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            //método .poll() desencola un elemento
            System.out.println(colaAutos.poll());
        }

        System.out.println("Longitud de cola: "+colaAutos.size());
        
        
        //Interface Map
        Map<String,String> mapaSemana=null;

        //Implemantación HashMap:   Es la implementación más veloz,
        //      no hay garantia de orden en los elementos.
        //mapaSemana=new HashMap();

        //Implementación Hashtable: Es igual a HashMap, pero es
        //      legacy. No se recomienda su uso.
        //mapaSemana=new Hashtable();

        //Implementación LinkedHashMap: Almacena elementos en
        //      una lista enlazada por orden de ingreso
        //mapaSemana=new LinkedHashMap();

        //Implementación TreeMap:   almacena elementos en un arbol
        //      ordenados en forma natural por llave.
        mapaSemana=new TreeMap();

        //App
        mapaSemana.put("lu", "xxx");
        mapaSemana.put("lu", "Lunes");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");
        System.out.println(mapaSemana.get("lu"));
        mapaSemana.forEach((k,v)->System.out.println(k+" : "+v));



        

    }  
}

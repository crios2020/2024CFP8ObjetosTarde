package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.entities.Auto;

public class TestCollection {
    public static void main(String[] args) {
        
        //Vectores - Arreglos
        Auto[] autos=new Auto[4];

        autos[0]=new Auto("Ford", "Ka", "Negro");
        autos[1]=new Auto("Fiat", "Toro", "Rojo");
        autos[2]=new Auto("Citroen", "C3", "Verde");
        autos[3]=new Auto("Renault", "Kangoo", "Bordo");

        //Recorrido con indices
        //for(int a=0; a<autos.length; a++){
        //    System.out.println(autos[a]);
        //}

        //Recorrido forEach
        for(Auto auto : autos) System.out.println(auto);

        //Interface List
        List lista1=new ArrayList();

        lista1.add(new Auto("Peugeot","205","Gris"));   //0
        lista1.add(new Auto("VW", "Gol", "Blanco"));    //1
        lista1.add("Hola");                                              //2
        lista1.add("Mundo");                                             //3
        lista1.add(26);                                                  //4

        lista1.add(1,"Java");
        lista1.remove(4);

        System.out.println("****************************************");
        //Recorrido con indices
        //for(int a=0; a<lista1.size(); a++){
        //    lista1.get(a);
        //}
        
        //Recorrido forEach
        //for(Object o: lista1) System.out.println(o);
        
        //Método default forEach()
        //lista1.forEach(o->System.out.println(o));

        //lista1.forEach(o->{
        //    System.out.println(o);
        //    System.out.println("-");
        //});

        lista1.forEach(System.out::println);

        //Uso de Generics <>        JDK 5 o sup
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Honda", "Civic", "Blanco"));

        //copiar autos del vector autos a lista2
        for(Auto auto: autos) lista2.add(auto);

        //copiar autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });

        //Recorrido de lista2
        System.out.println("****************************************");
        lista2.forEach(System.out::println);

        //Interface SET

    }  
}
